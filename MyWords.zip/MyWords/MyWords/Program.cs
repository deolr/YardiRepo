﻿using System;
using System.Diagnostics;
using System.IO;

namespace MyWords
{
	public struct CombinationWord
	{
		public string part1;
		public string part2;
		public string word;
	}
	class Program
	{
		//private static string textFile = @"C:\Users\Public\TestFiles\dictionary.txt";
		//private static string textFile = @"C:\Users\Rupinder\source\repos\MyWords\MyWords\TestFiles\dictionary.txt";
		private static string textFile =  Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\TestFiles\dictionary.txt");
		private static readonly IFunDictionary dict = new SortedSetDictionary();
		private const int DEFAULT_WORD_LENGTH = 6;
		private static int wordLength = DEFAULT_WORD_LENGTH;
		static void Main(string[] args)
		{
			if (args != null && args.Length>0)
				textFile = args[0];

			if (File.Exists(textFile))
			{
				// Read file using StreamReader. Reads file line by line  
				using StreamReader file = new StreamReader(textFile);
				Console.WriteLine($"Please wait while reading the input file.");

				int counter = 0;
				string line;

				//read each line from file and store the word in dictionary
				while ((line = file.ReadLine()) != null)
				{
					dict.Add(line);
					counter++;
				}
				Console.WriteLine($"File reading complete.");
				Console.WriteLine($"Input File has {counter} lines.");

				file.Close();


				bool inputValid = false;
				while (!inputValid)
				{
					Console.WriteLine();
					Console.WriteLine($"Default word length is 6. Would you like to change it? Press 1 for YES. otherwise press ENTER to continue:");
					//string input = Console.ReadLine();
					ConsoleKey key = Console.ReadKey().Key;
					if (key == ConsoleKey.Enter)
					{
						inputValid = true;
					}
					else if (key == ConsoleKey.D1)
					{
						Console.WriteLine();
						Console.WriteLine($"Please enter a number between 0 and 9:");

						var input = Console.ReadLine();
						int.TryParse(input, out int length);

						if (length > 0 && length <= 9)
						{
							wordLength = length;
							inputValid = true;
						}
						
					}
					else
					{
						Console.WriteLine();
						Console.WriteLine($"Input not valid.");
					}
				}
				
				var stopwatch = new Stopwatch();
				stopwatch.Start();

				var combiWords = dict.GetWordCombinationsOfLength(wordLength);

				((IPrintable)dict).PrintWords(combiWords);

				stopwatch.Stop();
				var elapsedTime = stopwatch.ElapsedMilliseconds;
				Console.WriteLine($"Task completed in {elapsedTime} ms. Press any key to exit.");

			}
			else
			{
				Console.WriteLine($"File not found at {textFile}");
			}

			Console.WriteLine($"Task complete. Press any key to exit.");

			Console.ReadKey();
		}


	}


}
