﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyWords
{
	public interface IFunDictionary
	{
		/// <summary>
		/// Add a word to dictionary
		/// </summary>
		/// <param name="word"></param>
		public void Add(String word);

		/// <summary>
		/// Gets all words of given length from the dictionary
		/// </summary>
		/// <param name="length">Length of words to search</param>
		/// <returns>Collection of words</returns>
		public IEnumerable<string> GetWordsOfLength(int length);
		
		/// <summary>
		/// Finds all pairs of words that when concatinated form another word in the dictionary
		/// </summary>
		/// <param name="length">Length of words to search for</param>
		/// <returns>Sorted collection of CombinationWord obejects</returns>
		public IDictionary<int, CombinationWord> GetWordCombinationsOfLength(int length);
	}
}
