﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace MyWords
{
	/// <summary>
	/// This class provides a data structure to store and search words.
	/// It uses a combination of both SortedSet and Trie data structues to provide better performance
	/// than using just the SortedSets
	/// </summary>
	public class SortedSetDictionary : IFunDictionary, IPrintable
	{
		private readonly IDictionary<int, SortedSet<string>> allWords = new Dictionary<int, SortedSet<string>>();

		public void Add(String word)
		{
			allWords.TryGetValue(word.Length, out SortedSet<string> wordSet);
			if (wordSet == null)
			{
				wordSet = new SortedSet<string>();
				allWords[word.Length] = wordSet;
			}
			wordSet.Add(word);
		}

		public IEnumerable<string> GetWordsOfLength(int length)
		{
			allWords.TryGetValue(length, out SortedSet<string> words);
			return words;
		}

		public IDictionary<int, CombinationWord> GetWordCombinationsOfLength(int length)
		{
			SortedSet<string> targetWords = (SortedSet<string>)GetWordsOfLength(length);

			Console.WriteLine($"Collecting combination words of length {length} STARTED. Please be patient as it may take a few minutes.");

			SortedList<int, CombinationWord> combinationWords = new SortedList<int, CombinationWord>();

			//GetWordCombinationsUsingLinq(targetWords, ref combiWords, length); //SLOWER
			GetWordCombinationsUsingTrie(targetWords, ref combinationWords, length); //FASTER

			Console.WriteLine($"Collecting combination words: FINISHED");
			return combinationWords;
		}

		
		/// <summary>
		/// Searches combination words using a Trie data structure
		/// </summary>
		/// <param name="targetWords">Collection of target words</param>
		/// <param name="combiWords">Container to store results</param>
		/// <param name="targetLength">max length of target words</param>
		private void GetWordCombinationsUsingTrie(SortedSet<string> targetWords, ref SortedList<int, CombinationWord> combiWords, int targetLength)
		{
			//add all target words to a Trie
			Trie trie = new Trie();
			trie.InsertRange(targetWords.ToList<string>());

			int count = 0;

			//iterate from smaller prefix to larger
			for (int i = 1; i <= targetLength; i++)
			{
				//get lists or prefix and suffix words that have the possibility of 
				//forming one of the target words when concatenated
				var prefixWords = GetWordsOfLength(i);
				var suffixWords = GetWordsOfLength(targetLength - i);
				if (prefixWords == null || suffixWords == null)
					continue;

				foreach (var part1 in prefixWords)
				{
					foreach (var part2 in suffixWords)
					{
						var word = part1 + part2;
						if (trie.Search(word))
						{
							CombinationWord combiWord = new CombinationWord
							{
								part1 = part1,
								part2 = part2,
								word = word
							};

							combiWords[count++] = combiWord;
						}
					}
				}
			}
		}

		/// <summary>
		/// Searches combination words using a linq operations
		/// NOTE: This operation runs slower than the one that uses Trie and is therefore commented out
		/// </summary>
		/// <param name="targetWords">Collection of target words</param>
		/// <param name="combiWords">Container to store results</param>
		/// <param name="targetLength">max length of target words</param>
		private void GetWordCombinationsUsingLinq(SortedSet<string> targetWords, ref SortedList<int, CombinationWord> combiWords, int targetLength)
		{
			int count = 0;

			//iterate from smaller prefix to larger
			for (int length = 1; length <= targetLength; length++)
			{
				//get lists or prefix and suffix words that have the possibility of 
				//forming one of the target words when concatenated
				var prefixWords = GetWordsOfLength(length);
				var suffixWords = GetWordsOfLength(targetLength - length);

				//if any of the prefix or suffix are empty we can't complete the word so skip it
				if (prefixWords == null || suffixWords == null)
					continue;

				var results = from x in prefixWords
							  from y in suffixWords
							  where targetWords.Contains(x + y)
							  select new CombinationWord
							  {
								  part1 = x,
								  part2 = y,
								  word = x + y
							  };

				//add results to the final collection
				foreach (var result in results)
					combiWords.Add(count++, result);
			}
		}

		public void PrintWords(IDictionary<int, CombinationWord> combiWords)
		{
			Console.WriteLine("Combination words are:");
			foreach (var key in combiWords.Keys)
			{
				combiWords.TryGetValue(key, out CombinationWord combiWord);
				Console.WriteLine($"{combiWord.part1} + {combiWord.part2} --> {combiWord.word}");
			}
			Console.WriteLine($"{combiWords.Count} Words were found:");
		}
	}
}
