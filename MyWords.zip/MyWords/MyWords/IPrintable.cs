﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyWords
{
	interface IPrintable
	{
		/// <summary>
		/// Prints combination words along with its parts
		/// </summary>
		/// <param name="combiWords">Collection of combination words</param>
		public void PrintWords(IDictionary<int, CombinationWord> combiWords);
	}
}
