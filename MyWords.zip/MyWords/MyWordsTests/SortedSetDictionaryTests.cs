using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyWords;
using System.Collections.Generic;
using System.Linq;

namespace MyWordsTests
{
	[TestClass]
	public class SortedSetDictionaryTests
	{
		private static readonly IFunDictionary dict = new SortedSetDictionary();
		private SortedList<int, CombinationWord> combinationWords = new SortedList<int, CombinationWord>();

		[ClassInitialize]
		public static void TestFixtureSetup(TestContext context)
		{
			dict.Add("programmer");
			dict.Add("lawyer");
			dict.Add("law");
			dict.Add("awyer");
			dict.Add("yer");
			dict.Add("la");
			dict.Add("wyer");
			dict.Add("l");
			dict.Add("fun");

		}

		[TestInitialize]
		public void Setup()
		{
			combinationWords.Clear();
		}

		[TestMethod]
		public void GetWordsOfLengthTest_length_3()
		{
			var result = dict.GetWordsOfLength(3);
			var word1 = result.ElementAt(0);
			var word2 = result.ElementAt(1);
			var word3 = result.ElementAt(2);

			Assert.AreEqual(3, result.Count(), "Should have exactly three items in the result in alphabatical order");
			Assert.AreEqual("fun", word1);
			Assert.AreEqual("law", word2);
			Assert.AreEqual("yer", word3);
		}

		[TestMethod]
		public void GetWordsOfLengthTest_length_6()
		{
			var result = dict.GetWordsOfLength(6);
			var word1 = result.ElementAt(0);

			Assert.AreEqual(1, result.Count(), "Should have exactly one word");
			Assert.AreEqual("lawyer", word1);
		}

		[TestMethod]
		public void GetWordsOfLengthTest_length_7()
		{
			var result = dict.GetWordsOfLength(7);
			Assert.IsNull(result, "The result should be null");
		}

		[TestMethod]
		public void GetWordsOfLengthTest_length_0()
		{
			var result = dict.GetWordsOfLength(0);
			Assert.IsNull(result, "The dict should have no words of length 0");
		}

		[TestMethod]
		public void GetWordCombinationsOfLengthTest_6_Count_Check()
		{
			var result = dict.GetWordCombinationsOfLength(6);
			Assert.IsNotNull(result, "The result should NOT be null");
			Assert.AreEqual(3, result.Count(), "There should be exactly 3 word combinations of length 6 chars");
		}

		[TestMethod]
		public void GetWordCombinationsOfLengthTest_6_Parts_Check_1()
		{
			var result = dict.GetWordCombinationsOfLength(6);
			var index = 0;
			var part1 = result[index].part1;
			var part2 = result[index].part2;
			Assert.AreEqual(part1, "l", "First part should match.");
			Assert.AreEqual(part2, "awyer", "Second part should match.");
		}

		[TestMethod]
		public void GetWordCombinationsOfLengthTest_6_Target_Check_2()
		{
			var result = dict.GetWordCombinationsOfLength(6);
			var index = 1;
			var part1 = result[index].part1;
			var part2 = result[index].part2;
			var targetWord = result[index].word;
			Assert.AreEqual(part1 + part2, targetWord, "Concatenating the two parts should be equal to the target word.");
		}

		[TestMethod]
		public void GetWordCombinationsOfLengthTest_6_Element_Check_3()
		{
			var result = dict.GetWordCombinationsOfLength(6);
			var index = 2;
			var part1 = result[index].part1;
			var part2 = result[index].part2;
			var targetWord = result[index].word;
			Assert.AreEqual(part1 + part2, targetWord, "Concatenating the two parts should be equal to the target word.");
		}

		[TestMethod]
		public void GetWordCombinationsOfLengthTest_6_Element_Check_4()
		{
			var result = dict.GetWordCombinationsOfLength(6);
			var targetWord = result[0].word;
			Assert.AreEqual(targetWord,"lawyer","The resulting word should match the target word");
		}


		[TestMethod]
		public void GetWordCombinationsOfLengthTest_6_Order_Check_4()
		{
			var result = dict.GetWordCombinationsOfLength(6);
			var word1Part1Length = result[0].part1.Length;
			var word2Part1Length = result[1].part1.Length;
			var word3Part1Length = result[2].part1.Length;
			Assert.IsTrue(word1Part1Length < word2Part1Length, "When target word is the same then words with shorter first part should come first");
			Assert.IsTrue(word2Part1Length < word3Part1Length, "When target word is the same then words with shorter first part should come first");
		}
	}
}
